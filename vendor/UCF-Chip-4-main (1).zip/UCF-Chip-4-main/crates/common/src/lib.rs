#![forbid(unsafe_code)]

pub mod digest;
